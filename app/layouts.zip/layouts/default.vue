<!-- eslint-disable vue/no-multiple-template-root -->
<template>
  <slot />
</template>

<!-- <style lang="css">
@reference '~/assets/css/main.css';
</style> -->
